import java.util.*;
public class Tuition
{

	public static void main(String[] args) 
	{
		double currentYear=10000;
	      double nextYear;
	      double total = 0;//Total of years 11 through 14
	      
	      for (int year=1; year <= 14;  year++)
	      {
	    	   if (year > 1)
	    	    System.out.println("Year: " + year + " Tuition: $"+currentYear);
	    	   
	    	   //Add up years 11 to 14
	    	   if (year > 10)
	    	   {
	    		   total = total + currentYear; 
	    	   }
	    	   
	    	    
	    	    
	    	  	nextYear = currentYear * 1.05;
	            currentYear = nextYear;
	      }  
	      
	      System.out.println("The total tuition for years 11 through 14 is $"+total);


	}

}
