import java.util.*;
public class ShippingCost 
{

	public static void main(String[] args) 
	{
		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Enter weight of package: ");
		double weight = keyboard.nextDouble();
		
		if (weight >= 0 && weight <= .999)
			System.out.println("The cost of shipping is $3.50 ");
		
		else if (weight >= 1 && weight <= 2.999)
			System.out.println("The cost of shipping is $5.50 ");
		
		else if (weight >= 3 && weight <= 9.999)
			System.out.println("The cost of shipping is $8.50 ");
		
		else if (weight >= 10 && weight <= 20)
			System.out.println("The cost of shipping is $10.50 ");
		
		else if (weight < 0)
			System.out.println("Invalid Input");
		
		else if (weight > 20)
			System.out.println("Package cannot be shipped");



	}

}
