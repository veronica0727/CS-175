import java.util.*;
public class Repeat 
{

	public static void main(String[] args)
	{
Scanner keyboard = new Scanner(System.in);
		
		System.out.println("How many days are in the month?");
		int days = keyboard.nextInt();
		
		System.out.println("  s  m  t  w th  f sat");
		for (int count=1; count <= days; count++)
		{	
		  System.out.printf("%3d",count);
		  
		  if (count % 7 == 0)
			  System.out.println();
		   
		}
		
		double result = 7.0/6;
		int number = 10;
		
		System.out.println("\n\nresult without using printf="+result);
		System.out.printf("\n\nresult with using printf=%5.2f",result);
	}

	}

