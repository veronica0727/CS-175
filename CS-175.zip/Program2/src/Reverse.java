import java.util.*;
public class Reverse 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		final int NUMBER_COUNT = 10;
		int[] value = new int[NUMBER_COUNT];
		int EntNum=0;
		int sum =0;
		do
		{
		System.out.print("Enter Number " + (EntNum + 1)+":");
        value[EntNum] = keyboard.nextInt();
        
        sum += value[EntNum];
        
        EntNum++;
       
		} while (EntNum < NUMBER_COUNT);
		
	// Print the values entered in reverse 
		System.out.print( "The numbers in reverse order are: " );
		
		for (int count = value.length - 1; count >= 0; count--)  
		System.out.print( value[count]+ " " );
	}
	

}
