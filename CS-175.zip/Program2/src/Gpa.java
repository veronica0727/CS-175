import java.util.*;
public class Gpa 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		//Ask for their grade
		System.out.print("Enter the student's average: ");
		double average = keyboard.nextDouble();
		
		//Receiving an "A" is between 90 and 100
		if (average >= 90 && average <= 100)
			System.out.println("This student's grade is an A ");
		
		//Receiving a "B+" is between 85 and 89.9
		else if (average >= 85 && average <= 89.9)
			System.out.println("This student's grade is a B+ ");
		
		//Receiving a "B-" is between 80 and 84.9
		else if (average >= 80 && average <= 84.9)
			System.out.println("This student's grade is a B- ");
		
		// Receiving a "C+" is between 75 and 79.9
		else if (average >= 75 && average <= 79.9)
			System.out.println("This student's grade is a C+ ");
		
		// Receiving a "C-" is between 70 and 74.9
		else if (average >= 70 && average <= 74.9)
			System.out.println("This student's grade is a C- ");
		
		//Receiving a "D" is between 60 and 69.9
		else if (average > 60 && average <= 69.9)
			System.out.println("This student's grade is a D ");
		
		//Receiving a "F" is less than 59
		else if (average <= 50)
			System.out.println("This student's grade is a F ");
		

	}

}
