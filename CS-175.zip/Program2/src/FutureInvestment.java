import java.util.*;
public class FutureInvestment 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in); 
	    System.out.print("The amount invested: ");
	 	double investment = keyboard.nextDouble();
	 	System.out.print("Annual rate of interest: ");
		double rate = keyboard.nextDouble();
		
		rate *= 0.01;
		
		System.out.println("\nYears    FutureValue");
		for(int count = 1; count <= 30; count++) {
	    	int formatter = 19;
		    if (count >= 10) formatter = 18;
			System.out.printf(count + "%"+formatter+".2f\n", futureInvestmentValue(investment, rate/12, count));
	       }
		 }
	 
	 public static double futureInvestmentValue(double investmentAmount, double monthlyInterestRate, int years) {
			return investmentAmount * Math.pow(1 + monthlyInterestRate, years * 12);
		}
	

	}


