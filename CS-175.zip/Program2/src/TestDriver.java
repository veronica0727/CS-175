import java.util.*;
public class TestDriver 
{

	public static void main(String[] args) 
	{
		double SalesAmountIn = 0;
		double CommissionOut = 0;
		
		System.out.println("SalesAmount\t\t\tComission");
		
		SalesAmountIn = 10000;
		CommissionOut = MyStuff.calcCommission(SalesAmountIn);
		for (int count = 1; count <= 19; count++)
		{
			System.out.printf("%1.0f\t\t\t\t%1.1f\n", SalesAmountIn, CommissionOut);
			SalesAmountIn = (SalesAmountIn + 5000);
			CommissionOut = MyStuff.calcCommission(SalesAmountIn);
		}
	}

}
