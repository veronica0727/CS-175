import java.util.*;
public class LastHomework 
{
	public class Exercise09_04Extra {
		  public void main(String[] args) {
		    SimpleTime time = new SimpleTime();
		    time.hour = 2;
		    time.minute = 3;
		    time.second = 4;
		    System.out.println("Hour: " + time.hour + " Minute: " 
		      + time.minute + " Second: " + time.second);
		  }
		}

		class SimpleTime 
		{
			public int second;
			public int minute;
			public int hour;
			

			    public int getHour() {
			        int mTime = 0;
					return (int)(mTime / (1000 * 60 * 60)) % 24;
			    }

			    public int getMinute() {
			        int mTime = 0;
					return (int)(mTime / (1000 * 60)) % 60;
			    }

			    public int getSecond() {
			        int mTime = 0;
					return (int)(mTime / 1000) % 60;
			    }

			}

			
		  // Complete the code to declare the data fields hour, 
		  // minute, and second of the int type
		}

