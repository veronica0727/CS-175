import java.util.*;
public class LectureArray 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		final int DAY_COUNT = 5; //Number of day for the forecast
		
		double[] temp = new double[DAY_COUNT]; //temp is an array of temperatures
		double highest=0;
		double lowest=0;
		double average=0;
		double sum=0;
		
		int daynum=0; //Keep track of the day being processed
		
	  do
	  {
		System.out.print("Enter temperature for day " + (daynum + 1)+":");
        temp[daynum] = keyboard.nextDouble();
        
        sum += temp[daynum]; //Add temp to sum...keep a running total of the temps
        		
        //For the 1st set the highest and lowest temp to that 1st day temp
        if (daynum == 0)
        {
        	highest = temp[daynum];
        	lowest  = temp[daynum];
        }
        else  //Adjust highest and lowest for days other than the 1st
        {	
          if (temp[daynum] > highest)
        	 highest = temp[daynum];
          
          if (temp[daynum] < lowest)
        	  lowest = temp[daynum];
        }
        
        daynum++; //Keep count of what day we're on
        
	  } while (daynum < DAY_COUNT); 
      
	  average = sum/DAY_COUNT; 
			  
	  System.out.println("\nHighest Temperature: " + highest);
	  System.out.println("Lowest Temperature: " + lowest);
	  System.out.println("Average Temperature: " + average);
	  
	  System.out.println("\n5 day forecast: ");
	  
	  for (int count=0; count<DAY_COUNT; count++)
	   System.out.println("Day "+ (count + 1) + " Temperature: " + temp[count]);
	  
	  //Print out temps that are above the average
	  
	  System.out.println("\nTemperature that are above average: ");
	  
	  for (int count=0; count<DAY_COUNT; count++)
	  {	  
	    if (temp[count] > average)
		  System.out.println("Day "+ (count + 1) + " Temperature: " + temp[count]);
	  }
	  
	  //Print out temps that are BELOW the average
	  
	  System.out.println("\nTemperature that are BELOW average: ");
	  
	  for (int count=0; count<DAY_COUNT; count++)
	  {	  
	    if (temp[count] < average)
		  System.out.println("Day "+ (count + 1) + " Temperature: " + temp[count]);
	  }
	}


	

	}


