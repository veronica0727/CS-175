
public class MyStuff 
{
	public static double calcCommission(double salesAmt)
	{
		double comOut;
		comOut = (5000 * .08) + (5000 * .10) + ((salesAmt - 10000)* .12);
		return comOut;
		
	}

	
	
}
