import java.util.*;
public class MilesToKilometers 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
	      double miles;
	      double kilometers = 0;
	      
	      
	      System.out.println("up to how many miles?" );
	      miles = keyboard.nextDouble();
	      
	     
	      
	      for (int count=1; count <= miles;  count++)
	      {
	    	  if (count == miles)
	    		  System.out.println("Miles    Kilometers\n" + miles + "      "   + kilometers);
	    	  		
	    	    
	    	   
	    	  
	    	   
	    	    
	    	    
	    	  	kilometers = miles * (1.609); 
	    	  	
	    	  	
	            
	      }  
	      
	      
	      }  
	      
	      
		
		
	}



